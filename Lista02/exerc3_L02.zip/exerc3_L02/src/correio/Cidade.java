package correio;

public enum Cidade {
	A, B
}
