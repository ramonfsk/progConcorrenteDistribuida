package correio;

public class Carta {

	private String nome;
	
	public Carta(String nome) {
		this.nome = nome;
	}
	
	/*public Carta escrvCarta(String nome) {
		Carta novaCarta = new Carta(nome);
		return novaCarta;
	}*/
	
	public String getNome() {
		return nome;
	}
}
