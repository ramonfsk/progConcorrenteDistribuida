package exerc2_L02;

public enum TipoImpressora {
	A, B
}
