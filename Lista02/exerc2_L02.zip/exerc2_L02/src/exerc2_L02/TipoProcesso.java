package exerc2_L02;

public enum TipoProcesso {
	PA, PB, PAB
}
