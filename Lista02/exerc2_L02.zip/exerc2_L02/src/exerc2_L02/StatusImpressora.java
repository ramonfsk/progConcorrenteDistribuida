package exerc2_L02;

public enum StatusImpressora {
	AGUARDANDO, IMPRIMINDO
}
