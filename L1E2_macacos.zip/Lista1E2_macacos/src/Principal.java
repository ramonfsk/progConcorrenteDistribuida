import selva.Lado;
import selva.Macaco;
import selva.Ponte;

public class Principal {

	public static void main(String[] args) {
		Ponte ponte = new Ponte();
		for (int i=1; i<=10; i++)
			(new Macaco("Macaco "+i, ponte, (i%2==0)?Lado.DIREITO:Lado.ESQUERDO)).start();
	}

}
