package selva;

public enum Lado {
	ESQUERDO, DIREITO;
}
