package selva;

import java.util.Random;

public class Macaco extends Thread {
	private Lado lado;
	private Ponte ponte;
	
	public Macaco(String nome, Ponte ponte, Lado lado) {
		super(nome);
		this.lado = lado;
		this.ponte = ponte;
	}
	
	public void run() {
		while (true) {
			this.comer();
			this.atravessar();
		}
	}
	
	public void  atravessar() {
		boolean atravessar;
		System.out.println("====> "+ super.getName() +"["+ this.lado +"] atravessar...");
		if (this.lado == Lado.ESQUERDO) {
			do {
				atravessar=ponte.irEsquerdaDireita(); 
				if (atravessar) { // Pode ir...
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					ponte.chegarDireita();
					this.trocarLado();
					System.out.println("====> "+ super.getName() +"["+ this.lado +"] atravessou!");
				}
				else { // N�o pode ir!
					synchronized (this.ponte) {
						try {
							System.out.println("=========> "+ super.getName() +"["+ this.lado +"] esperando...");
							this.ponte.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					System.out.println("=========> "+ super.getName() +"["+ this.lado +"] saindo da espera...");
				}
			} while (!atravessar);
		}
		else { // Lado.DIREITO
			do {
				atravessar=ponte.irDireitaEsquerda(); 
				if (atravessar) { // Pode ir...
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					ponte.chegarEsquerda();
					this.trocarLado();
					System.out.println("====> "+ super.getName() +"["+ this.lado +"] atravessou!");
				}
				else { // N�o pode ir!
					synchronized (this.ponte) {
						try {
							System.out.println("=========> "+ super.getName() +"["+ this.lado +"] esperando...");
							this.ponte.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					System.out.println("=========> "+ super.getName() +"["+ this.lado +"] saindo da espera...");
				}
			} while (!atravessar);
		}
	}
	
	public void comer() {
		System.out.println("----> "+ super.getName() +"["+ this.lado +"] comendo...");
		try {
			Thread.sleep((new Random()).nextInt(10000));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private void trocarLado() {
		this.lado = (this.lado==Lado.DIREITO)?Lado.ESQUERDO:Lado.DIREITO;
	}

}
