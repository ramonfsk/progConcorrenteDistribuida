package selva;

public class Ponte {
	private int contadorDireita;
	private int contadorEsquerda;
	
	public Ponte() {
	}
	
	public synchronized boolean irEsquerdaDireita() {
		if (this.contadorEsquerda != 0)
			return false;
		this.contadorDireita++;
		return true;
	}

	public synchronized boolean irDireitaEsquerda() {
		System.out.println("XXXXXXXXXXXXX --> ["+ this.contadorDireita +"]["+ this.contadorEsquerda +"]");
		if (this.contadorDireita != 0)
			return false;
		this.contadorEsquerda++;
		return true;
	}

	public synchronized void chegarDireita() {
		System.out.println("XXXXXXXXXXXXX --> ["+ this.contadorDireita +"]["+ this.contadorEsquerda +"]");
		this.contadorDireita--;
		if (this.contadorDireita == 0)
			this.notifyAll();
	}

	public synchronized void chegarEsquerda() {
		this.contadorEsquerda--;
		if (this.contadorEsquerda == 0)
			this.notifyAll();
	}

}
