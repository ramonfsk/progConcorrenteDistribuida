package exerc2_L03;

public enum TipoPessoa {
	Barbeiro, Cliente
}
