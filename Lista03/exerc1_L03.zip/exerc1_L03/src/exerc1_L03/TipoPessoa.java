package exerc1_L03;

public enum TipoPessoa {
	Professor, Funcionario, Aluno
}
