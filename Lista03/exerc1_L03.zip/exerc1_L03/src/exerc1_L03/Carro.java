package exerc1_L03;

public class Carro {
	
	private String modelo;
	
	public Carro(String modelo) {
		this.modelo = modelo;
	}

	public String getModelo() {
		return modelo;
	}
}
