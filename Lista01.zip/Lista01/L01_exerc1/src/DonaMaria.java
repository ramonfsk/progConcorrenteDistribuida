
public class DonaMaria extends Thread{
	public Tigela tigela;
	
	public DonaMaria(String nome, Tigela tigela) {
		super(nome);
		setTigela(tigela);
	}
	
	@Override
	public String toString() {
		return getName()+" criada com sucesso!";
	}
	
	@Override
	public void run() {
		while(true) {
			this.encherTigela();
			System.out.println(getName()+" rep�s a ra��o na tigela!");
			this.dormir();
		}
	}
	
	public void encherTigela() {
		tigela.reporRacao();
	}
	
	public void dormir() {
		int tempoDormir = (int)(Math.random() * 9999);
		try {
			System.out.println(getName()+" vai dormir por "+tempoDormir+"s.");
			sleep(tempoDormir);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public Tigela getTigela() {
		return tigela;
	}
	public void setTigela(Tigela tigela) {
		this.tigela = tigela;
	}
}
