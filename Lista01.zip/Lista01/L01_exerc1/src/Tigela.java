
public class Tigela {
	private int tamanhoTigela;
	private int qtdRacao;
	
	public Tigela(int tamanhoTigela) {
		setTamanhoTigela(tamanhoTigela);
	}
	
	@Override
	public String toString() {
		return "A tigela tem a capacidade de "+getTamanhoTigela()+"g de ra��o!";
	}
	
	public synchronized void comerRacao(int qtd) {
		while(qtd <= 0 || qtd > getTamanhoTigela()) {
			try {
				wait();
			} catch (Exception e) {}
			
		}
		setQtdRacao(getQtdRacao() - qtd);
		notifyAll();
	}
	
	public synchronized void reporRacao() {
		while(estaVazia()) {
			try {
				wait();
			} catch (Exception e) {}
		}
		setQtdRacao(getTamanhoTigela());
		notifyAll();
	}
	
	public boolean estaVazia() {
		if(getQtdRacao() == 0)
			return true;
		return false;
	}
	
	public int getTamanhoTigela() {
		return tamanhoTigela;
	}
	public void setTamanhoTigela(int tamanhoTigela) {
		Utils.validaInt(tamanhoTigela);
		this.tamanhoTigela = tamanhoTigela;
	}
	public int getQtdRacao() {
		return qtdRacao;
	}
	public void setQtdRacao(int qtdRacao) {
		Utils.validaInt(qtdRacao);
		this.qtdRacao = qtdRacao;
	}
}
