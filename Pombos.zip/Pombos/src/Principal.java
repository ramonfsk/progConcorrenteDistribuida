
public class Principal {
	public static void main(String[] args) {
		CaixaPostal caixaPostal = new CaixaPostal();
		Gaiola gaiola = new Gaiola();
		(new Tratador(gaiola)).start();
		for(int i =0; i< 13; i++){
			(new Pessoas(i,caixaPostal)).start();
			if(i<6){
				(new Pombo(i,caixaPostal,gaiola)).start();
			}
		}
		
	}
}
