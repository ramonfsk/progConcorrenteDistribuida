
public class Tratador extends Thread {
	Gaiola gaiola;
	
	Tratador(Gaiola gaiola){
		this.gaiola = gaiola;
	}
	
	public void run(){
		while(true){
			this.verificaGaiola();
		}
	}
	
	public void verificaGaiola(){
		try {
			sleep(20000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		gaiola.liberarPombo();
	}
}
