
public class Pombo extends Thread{
	int id;
	CaixaPostal caixaPostal;
	Gaiola gaiola;
	
	Pombo(int id, CaixaPostal caixa, Gaiola gaiola){
		this.caixaPostal = caixa;
		this.gaiola = gaiola;
		this.id = id;
	}
	
	public void run(){
		while(true){
			this.pegarCarta();
			
		}
	}
	
	public void pegarCarta(){
		boolean pegou = caixaPostal.entrega();
		if(pegou){
			System.out.println("O pombo " + this.id + " pegou 5 cartas");
			entregarCarta();
		} else {
			synchronized(this.caixaPostal){
				try {
					System.out.println("O pombo "+ this.id + " esta esperando por cartas");
					this.caixaPostal.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public void entregarCarta(){
		try {
			sleep(10000);
			System.out.println("O pombo" + this.id + " entregou as cartas");
			this.entraGaiola();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	public void entraGaiola(){
		gaiola.adicionarPombo();
		synchronized(this.gaiola){
			try {
				this.gaiola.wait();
				this.sairGaiola();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void sairGaiola(){
		try {
			sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
}
