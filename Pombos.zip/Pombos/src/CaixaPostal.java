
public class CaixaPostal {
	int contCartas;
	
	CaixaPostal(){
		this.contCartas = 0;
	}
	
	public synchronized void posta(){
		this.contCartas ++;
		System.out.println("Existem " + this.contCartas +" cartas na caixa!");
		if(this.contCartas >= 5){
			this.notify();
		}
	}
	
	public synchronized boolean entrega(){
		if(this.contCartas >= 5){
			this.contCartas -= 5;
			return true;
		}
		return false;
	}
	
}
