
public class Gaiola {
	int contPombo;
	
	Gaiola(){
		this.contPombo = 0;
	}
	
	public synchronized boolean liberarPombo(){
		if(this.contPombo < 2){
			return false;
		}
		this.contPombo = 0;
		this.notifyAll();
		System.out.println("Os Pombos foram soltos!");
		return true;
	}
	
	public synchronized void adicionarPombo(){
		this.contPombo ++;
		System.out.println("Existem " + this.contPombo + " pombos na gaiola");
	}
}
