
public class Pessoas extends Thread{
	CaixaPostal caixaPostal;
	int id;
	
	Pessoas(int id, CaixaPostal caixa){
		this.caixaPostal = caixa;
		this.id = id;
	}
	
	public void run(){
		while(true){
			escreve();
			posta();
		}
	}
	
	public void escreve(){
		try {
			sleep(40000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void posta(){
		caixaPostal.posta();
		try {
			sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
}
