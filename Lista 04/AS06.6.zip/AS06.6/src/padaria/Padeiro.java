package padaria;

public class Padeiro extends Thread {
	private Forno forno;
	private Pao pao = null;
	
	public Padeiro(String nome, Forno forno) {
		super(nome);
		this.forno = forno;
	}
	
	public void run() {
		while (true) {
			this.fazerMassa();
			this.forno.assarPao(this, pao);
		}
	}
	
	@SuppressWarnings("static-access")
	private void fazerMassa() {
		System.out.println("@@@--->>> " + this.getName() + " fazendo uma massa de pão.");
		this.pao = new Pao();
		try {
			this.sleep(5 * this.pao.getPeso());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("@@@--->>> " + this.getName() + " massa pronta.");
	}
}
