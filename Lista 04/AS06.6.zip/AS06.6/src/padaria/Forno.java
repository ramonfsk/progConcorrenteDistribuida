package padaria;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Forno {
	private int qtdPaes = 0;
	private Botijao botijao;
	private Lock lock;
	private Condition fornoLivre;
	private Condition reporGas;
	private Condition esperarGerente;
	
	public Forno(Botijao botijao, Lock lock, Condition fornoLivre, Condition reporGas, Condition esperarGerente) {
		this.botijao = botijao;
		this.lock = lock;
		this.fornoLivre = fornoLivre;
		this.reporGas = reporGas;
		this.esperarGerente = esperarGerente;
	}
	
	public int getQtdPaes() {
		return qtdPaes;
	}

	@SuppressWarnings("static-access")
	public void assarPao(Padeiro padeiro, Pao pao) {
		this.lock.lock();
		try {
			while (this.qtdPaes == 1) {
				try {
					this.fornoLivre.await();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			this.qtdPaes++;
			System.out.println("QTD PAES: " + this.qtdPaes + " NO FORNO");
			
			System.out.println("### " + padeiro.getName() + " está assando o pão.");
			
			if (!this.botijao.consumirGas(10 * pao.getPeso())) {
				System.out.println("!!! ACABOU O GÁS !!!");
				this.reporGas.signal();
				
				while (this.botijao.getCapacidade() == 0) {
					this.esperarGerente.await();
				}
			}
			
			padeiro.sleep(10 * pao.getPeso());
			pao.setAssado(true);
			
			this.qtdPaes--;
			this.fornoLivre.signal();
			System.out.println("### " + padeiro.getName() + " terminou de assar o pão.");
		} catch(InterruptedException e) {
			e.printStackTrace();
		} finally {
			this.lock.unlock();
		}
	}
}
