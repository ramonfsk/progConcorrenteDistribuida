package padaria;

import java.util.Random;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class Botijao {
	private static int CAPACIDADE_MAX = 30000; // Capacidade máxima: 1000 (1 segundo) * 60 (1 minuto) * 5 = 300000 milissegundos
	private int capacidade = Botijao.CAPACIDADE_MAX; 
	private Lock lock;
	private Condition fornoLivre;
	private Condition reporGas;
	private Condition esperarCliente;
	
	public Botijao(Lock lock, Condition fornoLivre, Condition reporGas, Condition esperarCliente) {
		this.lock = lock;
		this.fornoLivre = fornoLivre;
		this.reporGas = reporGas;
		this.esperarCliente = esperarCliente;
	}

	public int getCapacidade() {
		return capacidade;
	}
	
	public boolean consumirGas(int quantidade) {
		this.lock.lock();
		try {
			System.out.println("QUANTIDADE A SER CONSUMIDA: " + quantidade + " CAPACIDADE ATUAL: " + this.capacidade);
			if (quantidade >= this.capacidade) {
				this.capacidade = 0;
				return false;
			}	
			this.capacidade -= quantidade;
			return true;
		} finally {
			this.lock.unlock();
		}
	}
	
	@SuppressWarnings("static-access")
	public void reporGas(Gerente gerente) {
		this.lock.lock();
		try {
			while (this.capacidade != 0) {
				this.reporGas.await();
			}
			
			System.out.println("^^^ Gerente vai repôr o gás ^^^");
			gerente.sleep(new Random().nextInt(2000));
			this.capacidade = Botijao.CAPACIDADE_MAX;
			System.out.println("^^^ O Gerente terminou de repôr o gás ^^^");
			this.esperarCliente.signal();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			this.lock.unlock();
		}
	}
}
