package padaria;

import java.util.Random;

public class Pao {
	private boolean assado;
	private int peso;
	
	public Pao() {
		this.assado = false;
		this.peso = new Random().nextInt(1000);
	}

	public boolean isAssado() {
		return assado;
	}

	public void setAssado(boolean assado) {
		this.assado = assado;
	}

	public int getPeso() {
		return peso;
	}
}
