package principal;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import padaria.Botijao;
import padaria.Forno;
import padaria.Gerente;
import padaria.Padeiro;

public class Principal {
	public static void main(String[] args) {
		Lock lock = new ReentrantLock(true);
		Condition fornoLivre = lock.newCondition();
		Condition reporGas = lock.newCondition();
		Condition esperarGerente = lock.newCondition();
		
		Botijao botijao = new Botijao(lock, fornoLivre, reporGas, esperarGerente);
		Forno forno = new Forno(botijao, lock, fornoLivre, reporGas, esperarGerente);
		
		for (int i = 1; i <= 3; i++)
			new Padeiro("Padeiro("+i+")", forno).start();
		
		new Gerente(botijao, forno).start();
	}
}
