package exerc4_L04;

public class Gerente extends Thread {

	private static int cntGerentes = 1;
	private Botijao botijao;
	private Forno forno;
	
	public Gerente(Forno forno, Botijao botijao) {
		super("Gerente "+cntGerentes);
		this.forno = forno;
		this.botijao = botijao;
		cntGerentes++;
	}
	
	@Override
	public void run() {
		while(true)
			this.trocarBotijao();
	}
	
	public synchronized void trocarBotijao() {
		try {
			synchronized (this.botijao) {
				System.out.println(" $$$ O "+this.getName()+" est� aguardando uma notifica��o...");
				this.botijao.wait();
			}
			System.out.println("$$$ O "+this.getName()+" est� trocando o botijao!");
			this.forno.trocaBotijao(Botijao.criaBotijao(this.botijao.obtemTamGas()));
			System.out.println("$$$ O "+this.getName()+" TROCOU O BOTIJAO, VAMOS GLR!!");
			synchronized (this.forno) {
				this.forno.notifyAll();
			}
		} catch (InterruptedException e) { e.printStackTrace(); }
	}
}
