package exerc4_L04;

public class Botijao {
	
	private static int cntBotijoes = 1;
	private String nome;
	private long qtdGas;
	private long tamGas;
	
	public Botijao(long tamGas) {
		this.nome = "Botij�o "+cntBotijoes;
		this.tamGas = tamGas;
		this.qtdGas = tamGas;
		cntBotijoes++;
	}
	
	public static Botijao criaBotijao(long qtdGas) {
		return new Botijao(qtdGas);
	}
	
	public synchronized void consomeGas(long qtd) {
		this.qtdGas -= qtd;
		System.out.println("*** [CONSUMIDO "+qtd+"min DE G�S, RESTAM "+this.qtdGas+"!] ***");
	}
	
	public long obtemQntGasDisponivel() {
		return this.qtdGas;
	}
	
	public long obtemTamGas() {
		return this.tamGas;
	}
	
	public String obtemNome() {
		return this.nome;
	}
}
