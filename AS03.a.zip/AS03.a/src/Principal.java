import java.util.ArrayList;

public class Principal {
	public static void main(String[] args) {
		Tigela tigela = new Tigela(12);
		DonaMaria donaMaria = new DonaMaria("Dona Maria", tigela);
		
		int nroGatos = 12;
		ArrayList<Gato> gatos = new ArrayList<Gato>();
		
		for (int i = 0; i < nroGatos; i++) 
			gatos.add(new Gato("Gato("+(i+1)+")", tigela, donaMaria));
		
		for (Gato gato : gatos) {
			gato.start();
		}
		donaMaria.start();
	}
}
