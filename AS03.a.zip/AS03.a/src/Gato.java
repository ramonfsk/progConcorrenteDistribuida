
public class Gato extends Thread {
	private static int MAX_QTD_COME = 12;
	private static int MIN_QTD_COME = 1;
	
	private int quantoCome;
	private Tigela tigela;
	
	public Gato(String nome, Tigela tigela, DonaMaria donaMaria) {
		super(nome);
		this.tigela = tigela;
		this.quantoCome = (int) (Math.random() * (Gato.MAX_QTD_COME - Gato.MIN_QTD_COME) + Gato.MIN_QTD_COME);
	}
	
	public void run() {
		while(true) {
			this.comer();
			System.out.println(this.getName() + " comeu " + this.quantoCome + " da ração, quantidade: " + this.tigela.getQtdRacao());
			this.dormir();
		}
	}
	
	public void comer() {
		this.tigela.comeuRacao(this.quantoCome);
	}

	public void dormir() {
		long tempoDormir = (int)(Math.random() * 100);
		try {
			sleep(tempoDormir);
			System.out.println(this.getName() + " vair dormir " + tempoDormir);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
