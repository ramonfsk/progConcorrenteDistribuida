
public class Tigela {
	private int MAX_RACAO;
	public int qtdRacao;
	
	public Tigela(int maxRacao) {
		this.MAX_RACAO = maxRacao;
		this.qtdRacao = MAX_RACAO;
	}
	
	public int getQtdRacao() {
		return this.qtdRacao;
	}
	
	public synchronized void comeuRacao(int qtdRacaoComida) {
		while (this.qtdRacao <= 0 || qtdRacaoComida > this.qtdRacao) {
			try {
				wait();
			} catch(InterruptedException e) {}
		}
		this.qtdRacao -= qtdRacaoComida;
		this.notifyAll();
	}
	
	public synchronized void reposRacao() {
		while (this.qtdRacao > 0) {
			try {
				wait();
			} catch(InterruptedException e) {}
			
		}
		this.qtdRacao = this.MAX_RACAO;
		this.notifyAll();
	}
}
