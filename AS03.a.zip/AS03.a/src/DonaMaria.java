
public class DonaMaria extends Thread {
	private Tigela tigela;
	
	public DonaMaria(String nome, Tigela tigela) {
		super(nome);
		this.tigela = tigela;
	}
	
	public void run() {
		while(true) {
			this.repoerRacao();
			System.out.println(this.getName() + " repos a ração ");
			this.dormir();
		}
	}
	
	public void repoerRacao() {
		this.tigela.reposRacao();
	}
	
	public void dormir() {
		long tempoDormir = (int)(Math.random() * 100);
		try {
			sleep(tempoDormir);
			System.out.println("Dona maria vai dormir por " + tempoDormir);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
